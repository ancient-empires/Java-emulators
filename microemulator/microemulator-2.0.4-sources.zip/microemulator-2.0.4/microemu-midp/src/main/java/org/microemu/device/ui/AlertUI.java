package org.microemu.device.ui;

public interface AlertUI extends DisplayableUI {

	void setString(String str);
	
}
