<?php
    header('Location: /test/');
?>
