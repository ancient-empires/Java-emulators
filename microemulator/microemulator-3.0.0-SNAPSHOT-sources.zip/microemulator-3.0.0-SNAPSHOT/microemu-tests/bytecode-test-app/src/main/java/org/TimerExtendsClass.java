/**
 * 
 */
package org;

import java.util.Timer;

/**
 * @author vlads
 * 
 */
public class TimerExtendsClass extends Timer {

	public void doNothing() {

	}
}
